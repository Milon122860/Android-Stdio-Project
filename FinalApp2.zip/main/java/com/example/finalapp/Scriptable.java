package com.example.finalapp;

public class Scriptable {
}
